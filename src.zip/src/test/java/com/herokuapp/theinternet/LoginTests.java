package com.herokuapp.theinternet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class LoginTests {
	private WebDriver driver;
	
	@Parameters({ "browser" })
	@BeforeMethod(alwaysRun = true)
	private void setUp(@Optional String browser) {
		// create a driver
		switch (browser) {
		case "chrome":
			driver = new ChromeDriver();
			break;
		case "firefox":
			driver = new FirefoxDriver();
			break;
		default: 
			System.out.println("Do not know how to start " + browser + "starting chrome instead.");
			driver = new ChromeDriver();
			break;
		}

		//driver = new ChromeDriver();
		sleep(1);
		System.out.println("Browser is opened.");

		// open url (test page)
		String url = "http://the-internet.herokuapp.com/login";
		driver.get(url);
		driver.manage().window().maximize();
		// Wait 2 seconds
		sleep(1);

	}

	@Test(priority = 1, groups = { "positiveTests", "smokeTests" })
	public void positiveLoginTest() {
		System.out.println("Test started.");

		// enter username
		WebElement username = driver.findElement(By.id("username"));
		username.sendKeys("tomsmith");
		sleep(1);

		// enter password
		WebElement password = driver.findElement(By.name("password"));
		password.sendKeys("SuperSecretPassword!");
		sleep(1);

		// click on login
		WebElement logInButton = driver.findElement(By.tagName("but ton"));
		logInButton.click();

		sleep(1);

		// verification:
		// new url
		String expectedUrl = "http://the-internet.herokuapp.com/secure";
		String actualUrl = driver.getCurrentUrl();
		Assert.assertEquals(expectedUrl, actualUrl, "The actual url is not as expected.");

		// successful login message
		// WebElement successMsg = driver.findElement(By.cssSelector("div#flash"));
		WebElement successMsg = driver.findElement(By.xpath("//*[@id=\"flash\"]"));
		String expectedMssg = "You logged into a secure area!";
		String actualMsg = successMsg.getText();
		Assert.assertTrue(actualMsg.contains(expectedMssg),
				"Expected message does not contain actual message.\n Actual Messge: " + actualMsg + "\n");

		// logout button is visible
		WebElement logOutButton = driver.findElement(By.xpath("//a[@class='button secondary radius']"));
		// WebElement logOutButton =
		// driver.findElement(By.xpath("//*[@id=\"content\"]/div/a"));
		Assert.assertTrue(logOutButton.isDisplayed(), "The logout button is not displayed.");

	}

	@Parameters({ "username", "password", "expectedMessage" })
	@Test(priority = 2, groups = { "negativeTests", "smokeTests" })
	public void negativeLoginTest(String username, String password, String expectedErrorMessage) {
		System.out.println("Incorrect username Test started.");

		// open browser and create driver
		//WebDriver driver = new FirefoxDriver();
		System.out.println("Browser is opened.");
		sleep(1);
		// open url
		String url = "https://the-internet.herokuapp.com/login";
		driver.get(url);
		driver.manage().window().maximize();
		sleep(1);

		// enter incorrect username
		WebElement usernameElement = driver.findElement(By.id("username"));
		usernameElement.sendKeys(username);
		// enter correct password
		WebElement passwordElement = driver.findElement(By.id("password"));
		passwordElement.sendKeys(password); // click on login button
		WebElement logInButton = driver.findElement(By.xpath("//*[@id=\"login\"]/button"));
		logInButton.click();
		sleep(1);

		// Validate

		// error message displayed
		WebElement errorMsg = driver.findElement(By.xpath("//*[@id=\"flash\"]"));
		// String expectedErrorMessage = "Your username is invalid!";
		String actualMsg = errorMsg.getText();
		Assert.assertTrue(actualMsg.contains(expectedErrorMessage),
				"The actual error message is not as expected. \n Actual Messge: " + actualMsg + "\n Expected: "
						+ expectedErrorMessage);

		// login button displayed
		WebElement logInButton2 = driver.findElement(By.xpath("//*[@id=\"login\"]/button"));
		Assert.assertTrue(logInButton2.isDisplayed());
		System.out.println("The login button is displayed.");

		// Same url

		String expectedUrl = "https://the-internet.herokuapp.com/login";
		String actualUrl = driver.getCurrentUrl();
		Assert.assertEquals(expectedUrl, actualUrl, "The expected url is not as actual url.");
		System.out.println("The url is as expected.");

		// close window driver.close(); System.out.println("Test is finished.");

	}

	/**
	 * hold the excecution to observe
	 * 
	 * @param seconds
	 * 
	 */
	private void sleep(int seconds) {
		try {
			Thread.sleep(seconds * 1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@AfterMethod(alwaysRun = true)
	private void tearDown() {
		driver.close();
		System.out.println("Test is finished.");
	}

}
