package com.herokuapp.theinternet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class NegativeTests {

	@Parameters({ "username", "password", "expectedMessage" })
	@Test(priority = 1, groups = { "negativeTests", "smokeTests" })
	public void negativeLoginTest(String username, String password, String expectedErrorMessage) {
		System.out.println("Incorrect username Test started.");

		// open browser and create driver
		WebDriver driver = new FirefoxDriver();
		System.out.println("Browser is opened.");
		sleep(1);
		// open url
		String url = "https://the-internet.herokuapp.com/login";
		driver.get(url);
		driver.manage().window().maximize();
		sleep(1);

		// enter incorrect username
		WebElement usernameElement = driver.findElement(By.id("username"));
		usernameElement.sendKeys(username);
		// enter correct password
		WebElement passwordElement = driver.findElement(By.id("password"));
		passwordElement.sendKeys(password); // click on login button
		WebElement logInButton = driver.findElement(By.xpath("//*[@id=\"login\"]/button"));
		logInButton.click();
		sleep(1);

		// Validate

		// error message displayed
		WebElement errorMsg = driver.findElement(By.xpath("//*[@id=\"flash\"]"));
		//String expectedErrorMessage = "Your username is invalid!";
		String actualMsg = errorMsg.getText();
		Assert.assertTrue(actualMsg.contains(expectedErrorMessage),
				"The actual error message is not as expected. \n Actual Messge: " + actualMsg + "\n Expected: "
						+ expectedErrorMessage);

		// login button displayed
		WebElement logInButton2 = driver.findElement(By.xpath("//*[@id=\"login\"]/button"));
		Assert.assertTrue(logInButton2.isDisplayed());
		System.out.println("The login button is displayed.");

		// Same url

		String expectedUrl = "https://the-internet.herokuapp.com/login";
		String actualUrl = driver.getCurrentUrl();
		Assert.assertEquals(expectedUrl, actualUrl, "The expected url is not as actual url.");
		System.out.println("The url is as expected.");

		// close window driver.close(); System.out.println("Test is finished.");

	}

	/*
	 * @Test(priority = 1, groups = { "negativeTests", "smokeTests" }) public void
	 * IncorrectUsernameTest() {
	 * System.out.println("Incorrect username Test started.");
	 * 
	 * //open browser and create driver WebDriver driver = new FirefoxDriver();
	 * System.out.println("Browser is opened."); sleep(1); //open url String url =
	 * "https://the-internet.herokuapp.com/login"; driver.get(url);
	 * driver.manage().window().maximize(); sleep(1);
	 * 
	 * //enter incorrect username WebElement username =
	 * driver.findElement(By.id("username"));
	 * username.sendKeys("IncorrectUserName"); //enter correct password WebElement
	 * password = driver.findElement(By.id("password"));
	 * password.sendKeys("SuperSecretPassword!"); //click on login button WebElement
	 * logInButton = driver.findElement(By.xpath("//*[@id=\"login\"]/button"));
	 * logInButton.click(); sleep(1);
	 * 
	 * //Validate
	 * 
	 * //error message displayed WebElement errorMsg =
	 * driver.findElement(By.xpath("//*[@id=\"flash\"]")); String expectedMsg =
	 * "Your username is invalid!"; String actualMsg = errorMsg.getText();
	 * Assert.assertTrue(actualMsg.contains(expectedMsg),
	 * "The actual error message is not as expected. \n Actual Messge: " + actualMsg
	 * + "\n Expected: " + expectedMsg);
	 * 
	 * //login button displayed WebElement logInButton2 =
	 * driver.findElement(By.xpath("//*[@id=\"login\"]/button"));
	 * Assert.assertTrue(logInButton2.isDisplayed());
	 * System.out.println("The login button is displayed.");
	 * 
	 * //Same url
	 * 
	 * String expectedUrl = "https://the-internet.herokuapp.com/login"; String
	 * actualUrl = driver.getCurrentUrl(); Assert.assertEquals(expectedUrl,
	 * actualUrl, "The expected url is not as actual url.");
	 * System.out.println("The url is as expected.");
	 * 
	 * 
	 * 
	 * //close window driver.close(); System.out.println("Test is finished.");
	 * 
	 * }
	 * 
	 * /*
	 * 
	 * @Test(priority = 2, groups = { "negativeTests" }) public void
	 * IncorrectPasswordTest() {
	 * System.out.println("Incorrect password Test started.");
	 * 
	 * //open browser and create driver WebDriver driver = new ChromeDriver();
	 * System.out.println("Browser is opened."); sleep(1); //open url String url =
	 * "https://the-internet.herokuapp.com/login"; driver.get(url);
	 * driver.manage().window().maximize(); sleep(1);
	 * 
	 * //enter incorrect username WebElement username =
	 * driver.findElement(By.id("username")); username.sendKeys("tomsmith"); //enter
	 * correct password WebElement password = driver.findElement(By.id("password"));
	 * password.sendKeys("IncorrectPassword!"); //click on login button WebElement
	 * logInButton = driver.findElement(By.xpath("//*[@id=\"login\"]/button"));
	 * logInButton.click(); sleep(1);
	 * 
	 * //Validate
	 * 
	 * //error message displayed WebElement errorMsg =
	 * driver.findElement(By.xpath("//*[@id=\"flash\"]")); String expectedMsg =
	 * "Your password is invalid!"; String actualMsg = errorMsg.getText();
	 * Assert.assertTrue(actualMsg.contains(expectedMsg),
	 * "The actual error message is not as expected. \n Actual Messge: " + actualMsg
	 * + "\n Expected: " + expectedMsg);
	 * 
	 * //login button displayed WebElement logInButton2 =
	 * driver.findElement(By.xpath("//*[@id=\"login\"]/button"));
	 * Assert.assertTrue(logInButton2.isDisplayed());
	 * System.out.println("The login button is displayed.");
	 * 
	 * //Same url
	 * 
	 * String expectedUrl = "https://the-internet.herokuapp.com/login"; String
	 * actualUrl = driver.getCurrentUrl(); Assert.assertEquals(expectedUrl,
	 * actualUrl, "The expected url is not as actual url.");
	 * System.out.println("The url is as expected.");
	 * 
	 * 
	 * 
	 * //close window driver.close(); System.out.println("Test is finished.");
	 */



	private void sleep(int seconds) {
		try {
			Thread.sleep(seconds * 1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
