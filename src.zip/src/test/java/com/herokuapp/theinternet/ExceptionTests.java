package com.herokuapp.theinternet;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
//import org.openqa.selenium.JavascriptExecutor;

public class ExceptionTests {

private WebDriver driver;
	
	@Parameters({ "browser" })
	@BeforeMethod(alwaysRun = true)
	private void setUp(@Optional String browser) {
		// create a driver
		switch (browser) {
		case "chrome":
			driver = new ChromeDriver();
			break;
		case "firefox":
			driver = new FirefoxDriver();
			break;
		default: 
			System.out.println("Do not know how to start " + browser + "starting chrome instead.");
			driver = new ChromeDriver();
			break;
		}

		System.out.println("Browser is opened.");
		// open url (test page)
		String url = "https://practicetestautomation.com/practice-test-exceptions/";
		driver.get(url);
		driver.manage().window().maximize();

		
	}
	
	@Test
	//Test case 1
	public void noSuchExceptionTest() {

		
		System.out.println("Exceptions Test started!");
		WebElement row1AddButton = driver.findElement(By.id("add_btn"));
		row1AddButton.click();
		
		//Implicit wait
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		//Explicit Wait
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		WebElement row2Input = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"row2\"]/input")));

		//Verify Row 2 input field is displayed
		Assert.assertTrue(row2Input.isDisplayed(), "The Row2 box is not displayed." );
	}
	
	@Test
	//Test case 2
	public void elementNotInteractableExceptionTest() {
			
		System.out.println("ElementNotInteractableException Test started!");
		//Click Add button
		WebElement row1AddButton = driver.findElement(By.id("add_btn"));
		row1AddButton.click();
		//Wait for the second row to load
		//Explicit Wait
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		WebElement row2Input = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"row2\"]/input")));
		//Type text into the second input field
		row2Input.sendKeys("text");
		//Push Save button using locator By.name(“Save”)
	//	((JavascriptExecutor) driver).executeScript("document.getElementById('save_btn').style.display='block';");
		WebElement saveButtonElement = driver.findElement(By.xpath("//div[@id='row2']/button[@name='Save']"));
		
		saveButtonElement.click();
		//Verify text saved
		WebElement saveSuccessMsg = driver.findElement(By.xpath("//*[@id=\"confirmation\"]"));
		String actualSaveSuccessMsg = saveSuccessMsg.getText();
		String expectedSaveSuccessMsg = "Row 2 was saved";
		Assert.assertEquals(actualSaveSuccessMsg, expectedSaveSuccessMsg, "The actual message is not as expected.");
	}
	
	@Test
	//Test case 3
	public void InvalidElementStateExceptionTest() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1));
		//Clear input field
		WebElement editButtonElement = driver.findElement(By.xpath("//div[@id=\"row1\"]/button[@name=\"Edit\"]"));
		editButtonElement.click();
		
		//Type text into the input field
		WebElement row1TextElement = driver.findElement(By.xpath("//*[@id=\"row1\"]/input"));
		wait.until(ExpectedConditions.elementToBeClickable(row1TextElement));
		row1TextElement.clear();
		row1TextElement.sendKeys("Sushi");
		WebElement row1SaveButtonElement = driver.findElement(By.xpath("//div[@id='row1']/button[@name='Save']"));
		row1SaveButtonElement.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"confirmation\"]")));
		
		//Verify Text is saved
		String expectedSuccessMsg = "Row 1 was saved";
		WebElement actualSuccessMsgElement = driver.findElement(By.xpath("//*[@id=\"confirmation\"]"));
		String actualSuccessMsg = actualSuccessMsgElement.getText();
		Assert.assertEquals(actualSuccessMsg, expectedSuccessMsg, "The actual message is not as expected.");
	
		//Verify text changed
		String newText = row1TextElement.getAttribute("value");
		Assert.assertEquals(newText, "Sushi","The new value is not saved.");

	}
	
	@Test
	//Test case 4
	public void staleElementReferenceExceptionTest() {	
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		//Find the instructions text element
		WebElement instructionElement = driver.findElement(By.xpath("//div[@id='max-width']/section[@id='main-container']/section[@id='food_list']/p[@id='instructions']"));
		String instructionMsg = instructionElement.getText();
		String expectedInstructionMsg = "Push “Add” button to add another row";
		Assert.assertEquals(instructionMsg, expectedInstructionMsg, "The instruction is not as expected");
		
		//Push add button
		WebElement row1AddButton = driver.findElement(By.id("add_btn"));
		row1AddButton.click();
		
		//wait until row 2 is displayed
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"row2\"]/input")));

		//Verify instruction text element is no longer displayed
        Assert.assertTrue(wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@id='max-width']/section[@id='main-container']/section[@id='food_list']/p[@id='instructions']"))), "The instruction is still displayed.");		
	}
	
	@Test
	//Test case 5
	public void timeoutExceptionTest() {
		//Click Add button
		WebElement row1AddButton = driver.findElement(By.id("add_btn"));
		row1AddButton.click();
		
		//Wait for 3 seconds for the second input field to be displayed
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		WebElement row2Input = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"row2\"]/input")));

		//Verify second input field is displayed
		Assert.assertTrue(row2Input.isDisplayed(), "The Row2 box is not displayed." );
	}
	

	

	
	
	  @AfterMethod(alwaysRun = true) private void tearDown() { driver.close();
	  System.out.println("Test is finished."); }
	 
}
